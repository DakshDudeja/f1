function Courses() {
  return (
    <div className="App">
      <h3>Course 1</h3>
      <iframe
        src="https://www.youtube.com/embed/uXWycyeTeCs"
        width={1000}
        height={500}
        sandbox="allow-scripts allow-modal"
        loading="eager"
      ></iframe>
      <div>
        <p>Course Name:Course 1</p>
        <p>author:.............</p>
        <p>
          Course Description: lorem ipsu lorem ipsu lorem ipsulorem ipsuvlorem
          ipsuvvvlorem ipsuvlorem ipsuv lorem ipsulorem ipsulorem ipsulorem
          ipsuvvlorem ipsulorem ipsulorem ipsulorem i4 psuvlorem ipsuvlorem
          ipsulorem ipsu
        </p>
      </div>
    </div>
  );
}

export default Courses;
