import React, { useEffect } from "react";
import AppContextProvider from "./providersrc/context/ProviderApp";
import Home from "./providersrc/page/Home/Home";
import "./asset/scss/main.css";

export default function App() {
  useEffect(() => {
    document.title = "Static Job Listings - mdmahikaishar.me";
  }, []);

  return (
    <AppContextProvider>
      <Home />
    </AppContextProvider>
  );
}
