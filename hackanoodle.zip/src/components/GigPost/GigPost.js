import "./GigPost.css";
import { useState } from "react";
const GigPost = () => {
  const [pincode, setPincode] = useState("");
  const [duration, setDuration] = useState("");
  const [language, setLanguage] = useState("");
  const [interest, setInterest] = useState("");
  const [level, setlevel] = useState("");
  const [description, setDescription] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    // const details={title,body,expNum};
    // console.log(details);
    //the same fetch thing
  };
  return (
    <div className="create">
      <h2>Enter the details to avail the services</h2>
      <form onSubmit={handleSubmit}>
        <label>Your Pincode</label>
        <input
          value={pincode}
          onChange={(e) => setPincode(e.target.value)}
        ></input>

        <label>Industry</label>
        <select value={interest} onChange={(e) => setInterest(e.target.value)}>
          <option value="Software Development">Software Development</option>
          <option value="Data Science">Data Science</option>
          <option value="Manager">Manager</option>
          <option value="Heathcare">Software Development</option>
          <option value="First Aid Services">Software Development</option>
        </select>

        <label>Type</label>
        <select value={level} onChange={(e) => setlevel(e.target.value)}>
          <option value="Beginner">Beginner</option>
          <option value="Intermediate">Intermediate</option>
          <option value="Advanced">Advanced</option>
        </select>

        <label>Language</label>
        <select value={language} onChange={(e) => setLanguage(e.target.value)}>
          <option value="Hindi">Hindi</option>
          <option value="English">English</option>
          <option value="Telugu">Other</option>
        </select>

        <label>Duration</label>
        <input
          value={duration}
          onChange={(e) => setDuration(e.target.value)}
        ></input>

        <label>Description</label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        ></textarea>
        <button>Submit</button>
      </form>
    </div>
  );
};

export default GigPost;
