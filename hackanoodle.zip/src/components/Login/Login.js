import { React, useState } from "react";
import { Link } from "react-router-dom";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  let handleSubmit = async (e) => {
    e.preventDefault();
    try {
      let res = await fetch("https://httpbin.org/post", {
        method: "POST",
        body: JSON.stringify({
          email: email,
          password: password
        })
      });
      let resJson = await res.json();
      if (res.status === 200) {
        setEmail("");
        setPassword("");
      }
    } catch (err) {
      console.log(err);
    }
  };
  return (
    <div className="form-container">
      <form className="form-container-2">
        <h1>Log In</h1>

        <div className="input-container">
          <label className="title">Email</label>
          <div>
            <input
              className="email"
              type="email"
              placeholder="john.doe_1234@gmail.com"
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
        </div>

        <div className="input-container">
          <label className="title">Password</label>
          <div>
            <input
              className="password"
              type="password"
              placeholder="Aa123456"
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
        </div>

        <div className="sign-up-container">
          <button onSubmit={handleSubmit} className="sign-up">
            Log in
          </button>
        </div>
        <p className="sign-up-bottom-text">
          <Link to="/">Don't have an account? Sign-up</Link>
        </p>
      </form>
    </div>
  );
};

export default Login;
