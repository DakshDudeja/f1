import React from "react";
import { Link } from "react-router-dom";
import "./recommendedVideos.css";
import VideoCard from "./videoCard";

function RecommendedVideos() {
  const handleAIcamera = () => {};
  return (
    <div className="recommendedVideos">
      <Link to="/course1">
        <VideoCard
          courseTitle={"Course 1"}
          // imgSrc={"https://upload.wikimedia.org/wikipedia/commons/3/3b/Festival_Ringing_Cedars_2014_June_22_%D0%94%D0%B8%D0%BC%D0%BE%D0%BD_05.jpg"}
          instructor={"Kyle Pew, Office Newb LLC"}
          onClick={handleAIcamera}
        />
      </Link>

      <Link to="/course2">
        <VideoCard
          courseTitle={"Course 2"}
          // imgSrc={"https://img-a.udemycdn.com/course/240x135/914296_3670_8.jpg"}
          instructor={"Rob Percival, Daragh Walsh, Codestars by Rob Percival"}
        />
      </Link>

      <Link to="/course3">
        <VideoCard
          courseTitle={"Course 3"}
          // imgSrc={"https://img-a.udemycdn.com/course/240x135/1778502_f4b9_11.jpg"}
          instructor={"Dr. Anglea Yu"}
        />
      </Link>
      <Link to="/course4">
        <VideoCard
          courseTitle={"Course 4"}
          // imgSrc={"https://img-a.udemycdn.com/course/240x135/1203374_6d6f_3.jpg"}
          instructor={"Neil Anderson"}
        />
      </Link>

      <Link to="/course5">
        <VideoCard
          courseTitle={"Course 5"}
          // imgSrc={"https://img-a.udemycdn.com/course/240x135/1026604_790b_2.jpg"}
          instructor={"Jonas Schmedtmann"}
        />
      </Link>
    </div>
  );
}

export default RecommendedVideos;
