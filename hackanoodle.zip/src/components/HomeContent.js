import React from "react";
import AdImage from "../components/homeContent/adImage";
import Feature1 from "../components/homeContent/featureDiv/featureDiv1";
import Feature2 from "../components/homeContent/featureDiv/featureDiv2";
import Recommendations from "../components/homeContent/recommendations/recommendations";

function HomeContent() {
  return (
    <div>
      <AdImage />
      <Feature1 />
      <Recommendations />
      <Feature2 />
    </div>
  );
}

export default HomeContent;
