import { React, useState } from "react";
import { Link } from "react-router-dom";

const Signup = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [message, setMessage] = useState("");
  let handleSubmit = async (e) => {
    e.preventDefault();
    try {
      let res = await fetch("https://httpbin.org/post", {
        method: "POST",
        body: JSON.stringify({
          name: name,
          email: email,
          password: password,
          confirmPassword: confirmPassword,
          message: message
        })
      });
      let resJson = await res.json();
      if (res.status === 200) {
        setName("");
        setEmail("");
        setPassword("");
        setConfirmPassword("");
        setMessage("User created successfully");
      } else {
        setMessage("Some error occured");
      }
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <div className="form-container">
      <form onSubmit={handleSubmit} className="form-container-2">
        <h1>Sign Up</h1>
        <div className="input-container">
          <label className="title">Username</label>
          <div>
            <input
              className="username"
              type="text"
              placeholder="JohnDoe1234"
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>
        </div>
        <div className="input-container">
          <label className="title">Email</label>
          <div>
            <input
              className="email"
              type="email"
              placeholder="john.doe_1234@gmail.com"
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
        </div>
        <div className="input-container">
          <label className="title">Password</label>
          <div>
            <input
              className="password"
              type="password"
              placeholder="Aa123456"
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
        </div>
        <div className="input-container">
          <label className="title">Confirm Password</label>
          <div>
            <input
              className="confirm-password"
              type="password"
              placeholder="Aa123456"
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
            />
          </div>
        </div>
        <div className="sign-up-container">
          <button className="sign-up">Sign up</button>
        </div>
        <div className="message">{message ? <p>{message}</p> : null}</div>
        <p className="sign-up-bottom-text">
          <Link to="/login">Already have an account? Login</Link>
        </p>
      </form>
    </div>
  );
};

export default Signup;
